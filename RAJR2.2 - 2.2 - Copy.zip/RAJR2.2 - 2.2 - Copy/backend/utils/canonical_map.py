CANONICAL_MAP = {

    # Languages
    "c": "c",
    "c++": "c++",
    "cpp": "c++",
    "python": "python",
    "javascript": "javascript",
    "js": "javascript",

    # Frontend
    "html": "html",
    "html5": "html",
    "css": "css",
    "css3": "css",
    "bootstrap": "bootstrap",

    "react": "react",
    "reactjs": "react",
    "react.js": "react",
    "react js": "react",

    # Backend
    "node": "node js",
    "nodejs": "node js",
    "node.js": "node js",
    "node js": "node js",

    "express": "express js",
    "expressjs": "express js",
    "express.js": "express js",
    "express js": "express js",

    "ejs": "ejs",
    "rest api": "rest api",
    "rest apis": "rest api",

    # Databases
    "sql": "sql",
    "mysql": "mysql",
    "mongodb": "mongodb",
    "mongo db": "mongodb",

    # Tools
    "git": "git",
    "github": "github",
    "vscode": "vscode",
    "vs code": "vscode"
}
